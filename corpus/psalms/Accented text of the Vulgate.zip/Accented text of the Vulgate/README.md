Here you have an accented version of the Sixto-Clementine Vulgate.
The original text, which has been used for this work, is available here :
http://www.wilbourhall.org/pdfs/vulgate.pdf
The accentuation has been performed magna ex parte with Collatinus :
http://outils.biblissima.fr/fr/collatinus/
https://github.com/biblissima/collatinus
At this date (2017-04-18), these Books are available :
Mt
Mc
